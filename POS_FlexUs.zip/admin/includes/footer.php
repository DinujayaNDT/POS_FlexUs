<div class="row-fluid">
  <div id="footer" class="span12"> 2024 &copy; Inventory Management System  | <a href="https://mtrixlabs.com/"> Mtrixlabs </a></div>
</div>